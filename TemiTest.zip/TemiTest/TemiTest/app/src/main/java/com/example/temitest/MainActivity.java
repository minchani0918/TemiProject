package com.example.temitest;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.temitest.databinding.ActivityMainBinding;
import com.robotemi.sdk.Robot;
import com.robotemi.sdk.TtsRequest;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Robot robot;
    private SpeechRecognizer speechRecognizer;

    // 사전 입력된 텍스트
    private String preDefinedText = "안녕하세요, 테미입니다!";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        robot.askQuestion();
        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        robot = Robot.getInstance(); // Temi 객체 가져오기
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this); // 음성 인식 객체 초기화

        // STT 리스너 설정
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {}
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}
            @Override public void onError(int error) {
                Log.e("STT", "에러 발생: " + error);
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String recognizedText = matches.get(0);
                    Log.i("STT", "사용자가 말한 내용: " + recognizedText);
                }
            }

            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });

        // 버튼: Temi가 미리 지정된 텍스트를 말함
        Button buttonSpeak = findViewById(R.id.buttonSpeak);
        buttonSpeak.setOnClickListener(v -> {
            TtsRequest ttsRequest = TtsRequest.create(preDefinedText, false);
            robot.speak(ttsRequest);
        });

        // 버튼: 사용자의 말을 받아 텍스트로 변환해서 콘솔에 출력
        Button buttonListen = findViewById(R.id.buttonListen);
        buttonListen.setOnClickListener(v -> startListening());
    }

    private void startListening() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.KOREAN);
        speechRecognizer.startListening(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
    }
}
